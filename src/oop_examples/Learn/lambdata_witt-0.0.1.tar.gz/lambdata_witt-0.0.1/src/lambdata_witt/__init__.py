"""Collection of helper functions"""

import pandas as pd 
import numpy as np 

print("Stuff")